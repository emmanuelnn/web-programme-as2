<h2>Internet Joke Database</h2>

<p>Welcome to the Internet Joke Database</p>

<p>The first joke added to the internet joke database was <em><?=$joke['joketext']?></em></p>