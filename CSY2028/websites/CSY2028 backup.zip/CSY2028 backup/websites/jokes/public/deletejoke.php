<?php

require '../database.php';
require '../DatabaseTable.php';
$jokeTable = new DatabaseTable($pdo, 'joke', 'id');

$jokeTable->delete('id', $_POST['id']);

header('location: jokes.php');