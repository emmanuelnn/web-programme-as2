<?php
require '../loadTemplate.php';
require '../database.php';
require '../DatabaseTable.php';
require '../controllers/JokeController.php';

$jokeTable = new DatabaseTable($pdo, 'joke', 'id');

$JokeController = new JokeController($jokeTable);

if ($_SERVER['REQUEST_URI'] !== '/') {
    $funtionName = ltrim(explode('?', $_SERVER['REQUEST_URI'])[0], '/');
    $page = $JokeController->$funtionName();
}
else {
    $page = $JokeController->home();
}


$output = loadTemplate('../templates/' . $page['template'], $page['variables']);

$title = $page['title'];

require  '../templates/layout.html.php';