<?php

require '../loadTemplate.php';

require '../database.php';

require '../DatabaseTable.php';
$jokeTable = new DatabaseTable($pdo, 'joke', 'id');


if (isset($_POST['submit'])) {

	if ($_POST['joke']['id']==''){
		$_POST['joke']['id'] = null;
	}

	$jokeTable->save($_POST['joke']);
	
	header('location: jokes.php');
}
else {
	if (isset($_GET['id'])) {
		$joke = $jokeTable->find('id', $_GET['id'])[0];
		}
		else {
		$joke = false;
		}
	$output = loadTemplate('../templates/editjoke.html.php', ['joke' => $joke]);
	$title = 'Edit joke';
}

require  '../templates/layout.html.php';