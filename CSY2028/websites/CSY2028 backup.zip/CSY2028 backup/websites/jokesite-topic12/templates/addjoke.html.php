<form action="" method="post">
		<label for="joketext">Type your joke here:</label>
		<textarea id="joketext" name="joketext" rows="3" cols="40"></textarea>
		<input type="submit" value="Add">
</form>