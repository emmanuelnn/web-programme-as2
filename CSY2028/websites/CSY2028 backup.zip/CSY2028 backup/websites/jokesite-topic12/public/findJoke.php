
<?php
$joke = findJoke($pdo, 123);
$joke = findJoke($pdo, $_GET['id']);
?>