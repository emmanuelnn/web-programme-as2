<?php
require '../loadTemplate.php';
$title = 'Internet Joke Database';

$output = loadTemplate('../templates/home.html.php', []);

require  '../templates/layout.html.php';