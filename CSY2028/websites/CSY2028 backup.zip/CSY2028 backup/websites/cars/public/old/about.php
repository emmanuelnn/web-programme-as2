<?php
require '../functions/loadTemplate.php';
require '../autoload.php';
$title = 'Claires Cars - Home';

$output = loadTemplate('../templates/about.html.php', []);


require  '../templates/layout.html.php';

