<?php
require '../functions/loadTemplate.php';
require '../autoload.php';
$title = 'Internet Joke Database';

$output = loadTemplate('../templates/careers.html.php', []);


require  '../templates/layout.html.php';