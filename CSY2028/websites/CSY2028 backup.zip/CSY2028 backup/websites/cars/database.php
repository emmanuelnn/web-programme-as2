<?php
$pdo = new PDO('mysql:dbname=cars;host=mysql', 'student', 'student');

