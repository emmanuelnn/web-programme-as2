<?php
session_start();



$server = 'mysql';
$username = 'student';
$password = 'student';
//The name of the schema we created earlier in MySQL workbench
//If this schema does not exist you will get an error!
$schema = 'CSY2028';

$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

if (isset($_POST['submit'])) {
	$stmt = $pdo->prepare('INSERT INTO CSY2028.register(username, userpassword, name) 
    VALUES (:username, :userpassword, :name)');

    $userpassword = $_POST['userpassword'];

    $hash = password_hash($userpassword, PASSWORD_DEFAULT);
    

        $values = [
            'username' => $_POST['username'],
            'userpassword' => $hash,
            'name' => $_POST['name']
        ];

        $stmt->execute($values);

        echo $_POST['name'] . ' has been registered';
    }
    else {
        ?>
    
        <form action="registerform.php" method="post">
    
            <label>Username</label>
            <input type="text"  name="username" />
    
            <label>Password</label>
            <input type="password"  name="userpassword" />

            <label>Name</label>
            <input type="text"  name="name" />


            <input type="submit" value="submit" name="submit" />
        </form>
        <?php
    }
?>


