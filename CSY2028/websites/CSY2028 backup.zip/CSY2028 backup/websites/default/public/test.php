<?php
echo '<h1>My First PHP script</h1>';
?>