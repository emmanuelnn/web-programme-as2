<?php
$myVariable = 'University of Northampton - Software Engineering 2';
$myContent ='<h1>CSY2006 Software Engineering 2</h1>


<p>This purpose of this module is to provide consolidation and extension of the level 4 skills, understanding and knowledge derived from the earlier object-oriented experience; provide a framework of good practice, which will facilitate the development of larger systems; revisit many topics from earlier modules in a different object-oriented language and consider them in greater depth. The module will enable the students to compare some existing popular object-oriented languages/tools and analyse advantages/disadvantages of each.
</p>';

require '../layout.php';

?>