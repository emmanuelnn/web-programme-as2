<?php
$myVariable = 'University of Northampton - Operating Systems';
$myContent ='<h1>CSY2002 Operating Systems</h1>


<p>This year 2 module is designed to give an understanding of the principles, application, structure and design principles of operating systems.  The module requires a significant practical element delivered as formal laboratory sessions in which computer systems skills are acquired. </p>
';

require '../layout.php';

?>