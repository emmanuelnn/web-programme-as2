<?php
session_start();
$server = 'mysql';
$username = 'student';
$password = 'student';
//The name of the schema we created earlier in MySQL workbench
//If this schema does not exist you will get an error!
$schema = 'CSY2028';

$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

if (isset($_POST['submit'])) {
    
    $stmt = $pdo->prepare('SELECT * FROM register WHERE username = :username');
    $values = [
     'username' => $_POST['username'],
    ];
    $stmt->execute($values);
    $user = $stmt->fetch();

    if (password_verify($_POST['userpassword'], $user['userpassword'])) {
     $_SESSION['loggedin'] = $user['registerid'];
    }
    else {
     echo 'Sorry, your account could not be found';
    }
    
}
       
       else {
           
        ?>
        <form action="login2.php" method="POST">
         <label>Username: </label> <input type="text" name="username" />
         <label>Password: </label> <input type="password" name="userpassword" />
         <input type="submit" name="submit" value="Log In" />
        </form>
        <?php
        }
        ?>