<?php
$myVariable = 'University of Northampton - Computer Networks';
$myContent = '<h1>CSY2028 Web Prqogramming</h1>


<p> The aim of this module is to develop the students understanding of the concepts and technologies of Webbased server software applications, as well as expanding the
    students skills in corresponding software development. </p>';

require '../layout.php';

?>