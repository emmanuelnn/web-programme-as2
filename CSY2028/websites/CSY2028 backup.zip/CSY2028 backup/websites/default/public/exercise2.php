

<?php
function p($text) {
 return '<p>'. $text . '<p>';
}
echo p('Paragraph 1');
echo p('Paragraph 2');
?>



<?php

function html($tag, $text) {
    return '<'.$tag.'>' .$text.'</'. $tag.'>';
}
echo html('h1', 'Heading');
echo html('p', 'Paragraph 1');
echo html('li', 'List item 1');
echo html('li', 'List item 2');

?>


<?php

function html2($tag, $text) {
    return '<'.$tag.'>' .$text.'</'. $tag.'>';
}
echo html2('h1', 'Heading');
echo html2('p', 'Paragraph 1');

$List = html2('li', 'List item 1') . html('li', 'List item 2');
echo html2('ul', $List);


?>



