<?php
session_start();
unset($_SESSION['loggedin']);
echo '<h1>You are now logged out</h1>';

echo '<p><a href="login.php">click here to log back in</a></p>';