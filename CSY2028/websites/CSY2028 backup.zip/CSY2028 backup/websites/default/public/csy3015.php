<?php
$myVariable = 'University of Northampton - Real Time and and Embedded Systems';
$myContent ='<h1>CSY3015 Real Time and and Embedded Systems</h1>


<p>This module is designed to give an indepth appreciation of the design, implementation and testing principles of embedded and real-time systems. Issues involved and complexities of the use of computers in embedded systems and interfacing with such devices. </p>
';

require '../layout.php';

?>