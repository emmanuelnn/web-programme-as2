<?php




$myArray = [];


$myArray['John'] = '389';
$myArray['Kate'] = '012';
$myArray['Sue'] = '586';
$myArray['Dave'] = '675';
$myArray['Jo'] = '434';



foreach ($myArray as $key => $value) {
    echo '<ul>';
    echo '<li><a href="name.php?name='.$key. '">'. $key.'</a></li>' ;
    echo '</ul>';
   }
   

?>