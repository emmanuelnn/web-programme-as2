<?php
session_start();
if (isset($_SESSION['loggedin'])) {
 echo '<a href="logout.php">You are logged, click to logout</a>' ;
}
else {
 echo '<a href="login.php">You are not logged in, click to log in</a>';
}