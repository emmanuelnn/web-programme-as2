

<?php
$server = 'mysql';
$username = 'student';
$password = 'student';

$schema = 'CSY2028';
$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

if (isset($_POST['submit'])) {
$stmt = $pdo->prepare('INSERT INTO person (email, firstname, surname)
 VALUES (:email, :firstname, :surname)
');
$values = [
 'firstname' => $_POST['firstname'],
 'surname' => $_POST['surname'],
 'email' => $_POST['email']
 ];
$stmt->execute($values);
}
else {
?>
<form action="add.php" method="POST">
<label>First name:</label>
<input type="text" name="firstname" />
<label>Surname:</label>
<input type="text" name="surname" />
<label>Email:</label>
<input type="text" name="email" />
<input type="submit" name="submit" value=”Submit” />
</form>
<?php
}