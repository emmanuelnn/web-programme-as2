<form action="week6ex1.php" method="GET">
 <input type="text" name="input1" />
 <input type="submit" value="Submit" name="submit" />
</form>

<?php

//$_GET form
if (isset($_GET['input1'])) {

echo 'Hello ' . $_GET['input1'];
 
}


?>


<form action="week6ex1.php" method="GET">
 <input type="text" name="num1" />
 <input type="text" name="num2" />
 <input type="submit" value="Submit" name="submit" />
</form>


<?php

if (isset($_GET['submit'])) {
echo $_GET['num1'] * $_GET['num2'];
}
?>





