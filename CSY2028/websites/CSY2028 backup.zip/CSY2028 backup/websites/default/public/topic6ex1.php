<?php

$myArray = ['One', 'Two', 'Three']; //YOU CAN DO THE LOOP ONE AS WELL

echo '<p>' . $myArray[0] . '</p>';
echo '<p>' . $myArray[1] . '</p>';
echo '<p>' . $myArray[2] . '</p>';

?>



<?php
function showNumber($num1) {
 $numbers = [];
 $numbers[0] = 'Zero';
 $numbers[1] = 'Zero';
 
}
echo showNumber(6);
echo showNumber(22);
echo showNumber(10);
?>