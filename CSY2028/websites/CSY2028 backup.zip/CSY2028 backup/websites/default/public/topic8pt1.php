
<?php

$server = 'mysql';
$username = 'student';
$password = 'student';

$schema = 'CSY2028';
$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

$results = $pdo->query('SELECT * FROM person');
foreach ($results as $row) {
 echo '<p>' . $row['firstname'] . ' ' . $row['surname'] . ' was born on ' . $row['birthday'] . ' and their email address is ' . $row['email'] . '</p>';
}

?>


<?php
$server = 'mysql';
$username = 'student';
$password = 'student';

$schema = 'CSY2028';
$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);


$surname = 'Smith';
$results = $pdo->query('SELECT * FROM person WHERE surname = "' . $surname . '"');
foreach ($results as $row) {
 echo '<p>' . $row['firstname'] . ' ' . $row['surname'] . ' was born on ' . $row['birthday'] . '</p>';
}



?>
