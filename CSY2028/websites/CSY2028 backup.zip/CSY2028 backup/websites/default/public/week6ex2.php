<link rel="stylesheet" href="week6.css"/>


<form action="week6ex2.php" method="GET">
<label for="firstname">First Name</label> <input type="text" name="firstname" />
<label for="surname">Surname</label> <input type="text" name="surname" />
<label for="email">Email address</label> <input type="text" name="email" />



<label for="email">Favourite colour</label> <select name="colour">
            <option value="red">Red</option>
            <option value="green">Green</option>
            <option value="blue">Blue</option>
            </select>


<label for="Address">Address</label> <textarea name="Address"> </textarea>
 <label for="Address">Do you accept the terms and conditions?</label> <input type="checkbox" name="mycheckbox" value="ticked" />

 <input type="submit" value="Submit" name="submit" />
</form>