<?php
$myVariable = 'University of Northampton - Computer Communications';
$myContent ='			<h1>CSY1017 Computer Communications</h1>


<p>This module aims to give the student a comprehensive and broad understanding of the theory of computer networking.</P>
';
require '../layout.php';
?>