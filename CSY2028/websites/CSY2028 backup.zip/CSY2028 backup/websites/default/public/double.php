<?php
echo $_GET['num']*2;
?>