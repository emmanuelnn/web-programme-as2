<?php
$server = 'mysql';
$username = 'student';
$password = 'student';
//The name of the schema we created earlier in MySQL workbench
//If this schema does not exist you will get an error!
$schema = 'CSY2028';

$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

if (isset($_POST['submit'])) {
	$stmt = $pdo->prepare('INSERT INTO CSY2028.game(name, platformID) VALUES (:name, :platformID)');
        
        $values = [
            'name' => $_POST['name'],
            'platformID' => $_POST['platformID']
        ];

        $stmt->execute($values);
        echo 'Game' . $_POST['name'] . ' added';

}

    else {
        ?>
        <form action="addGame.php" method="post">
        <label>Game name:</label>
        <input type="text"  name="name" />
        <label>Select platform:</label>
        <select name="platformID">
            <?php

            $stmt = $pdo->prepare('SELECT * FROM CSY2028.platforms');
            $stmt->execute();

            foreach ($stmt as $row) {
                echo '<option vaule="' . $row['id'] . '">' . $row['name'] . '</option>';
            }



            ?>
        </select>
        <input type="submit" value="Add" name="submit" />
        </form>
        <?php
    }

?>
