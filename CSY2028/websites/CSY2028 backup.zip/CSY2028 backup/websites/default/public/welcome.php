<?php
session_start();
echo 'Welcome back' . $_SESSION['name'];