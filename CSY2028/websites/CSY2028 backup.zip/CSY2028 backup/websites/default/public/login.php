<?php
session_start();
if (isset($_POST['submit'])) {
    
        //Check they entered the correct username/password
        if ($_POST['username'] === 'csy2028' && $_POST['password'] === 'secret') {

            $_SESSION['loggedin'] = true;


            echo '<p><a href="logincheck.php">go to log in check</a></p>';

           
        }
         else {
            echo '<p>You did not enter the correct username and password</p>';

            echo '<a href="login.php">click here to log back in</a>';
         }
    }

        
       
       else {
           
        ?>
        <form action="login.php" method="POST">
         <label>Username: </label> <input type="text" name="username" />
         <label>Password: </label> <input type="password" name="password" />
         <input type="submit" name="submit" value="Log In" />
        </form>
        <?php
        }
        ?>