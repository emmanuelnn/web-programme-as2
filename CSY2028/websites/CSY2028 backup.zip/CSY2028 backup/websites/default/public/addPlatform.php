<?php
$server = 'mysql';
$username = 'student';
$password = 'student';
//The name of the schema we created earlier in MySQL workbench
//If this schema does not exist you will get an error!
$schema = 'CSY2028';

$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

if (isset($_POST['submit'])) {
	$stmt = $pdo->prepare('INSERT INTO CSY2028.platforms(name)
						   VALUES (:name)');


	$values = [
	
		'name' => $_POST['name'],
	];
	
	$stmt->execute($values);

	echo 'Record Added';

	echo '<p><a href="index1.php">Back to list</a>';
}
else {
	?>

	<form action="addPlatform.php" method="post">

		<label>Name</label>
		<input type="text"  name="name" />

		<input type="submit" value="submit" name="submit" />
	</form>
	<?php
}
