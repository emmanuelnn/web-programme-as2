<?php
$myVariable = 'University of Northampton - Computer Networks';
$myContent ='				<h1>CSY2001 Computer Networks</h1>


<p>The module is designed to provide students with an understanding of the concepts, structures and function of modern communication networks as well as the standards and protocols regulating the transfer of data.  </p>
';

require '../layout.php';

?>