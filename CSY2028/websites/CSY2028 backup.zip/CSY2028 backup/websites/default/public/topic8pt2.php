





<?php
$server = 'mysql';
$username = 'student';
$password = 'student';

$schema = 'CSY2028';
$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);

if (isset($_POST['field']== 'firstname'|| $_POST['field']=='surname')) {
    $stmt = $pdo->prepare('SELECT * FROM person 
                                WHERE '. $_POST['surname'] . '= :Nwokoro ');

    $values = [
     'firstname' => $_POST['firstname'],
     ];
    $stmt->execute($values);
    }
else {
?>




<form action="topic8pt2.php" method="POST">
<label>First name:</label>
<input type="text" name="firstname" />

<input type="submit" name="submit" value=”Submit” />
</form>
<?php
}