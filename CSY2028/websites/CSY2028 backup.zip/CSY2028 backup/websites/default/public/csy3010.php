<?php
$myVariable = 'University of Northampton - Media Technology';
$myContent ='<h1>CSY3010 Media Technology</h1>


<p>Media Technology is an important aspect to Computer Science. This Media Technology module is designed to introduce the technology relevant to multi-media systems. This includes computer graphics, text, audio and video. Media manipulation techniques are studied. Media compression techniques are also investigated. In addition the module provides an insight into colour spaces and their relevance. The module develops a framework from which the student can develop multimedia systems in a third generation computer language. </p>
';

require '../layout.php';

?>