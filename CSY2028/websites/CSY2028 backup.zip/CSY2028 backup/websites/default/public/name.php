<?php
session_start();
if (isset($_POST['submit'])) {
 $_SESSION['name'] = $_POST['name'];
 echo 'Welcome back ' . $_SESSION['name'];
}


else {
?>
<form action="name.php" method="POST">
 <label>Enter your name: </label>
 <input type="text" name="name" />
 <input type="submit" name="submit" value="Submit" />
</form>
<?php
}