<?php
function dice() {
$roll = rand(1,6);


echo str_replace('NAME', $roll, 'You rolled a NAME');

echo '<p>You rolled a ' . $roll . '<p>';
}


dice();
dice();
dice();
dice();
dice();
?>