</main>

<footer>
    &copy; Northampton News 2017
</footer>

</body>
</html>
