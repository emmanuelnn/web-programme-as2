<?php
namespace Ijdb\Controllers;
class Category {
	private $authorsTable;

	public function __construct($authorsTable) {
		$this->authorsTable = $authorsTable;
	}



}